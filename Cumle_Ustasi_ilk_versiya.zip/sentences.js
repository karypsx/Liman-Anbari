// Öz cümlələrini bu siyahıya əlavə et. Hər cümlə üçün ingiliscə, tərcümə və səviyyə yaz.
// Səviyyələr: A1, A2, B1, B2. Dırnaq işarələrinin içindəki mətni dəyiş; vergül və {} mötərizələrini saxla.
window.SENTENCES = [
  { en: "My sister drinks tea every day.", az: "Bacım hər gün çay içir.", level: "A1" },
  { en: "He bought a book yesterday.", az: "O, dünən kitab aldı.", level: "A1" },
  { en: "My brother is watching TV now.", az: "Qardaşım indi televizora baxır.", level: "A1" },
  { en: "We usually eat breakfast at 8.", az: "Biz adətən saat 8-də səhər yeməyi yeyirik.", level: "A1" },
  { en: "Sara met her friends in the park after school.", az: "Sara dərsdən sonra parkda dostları ilə görüşdü.", level: "A2" },
  { en: "My family stayed at home and watched a film yesterday because it was raining.", az: "Dünən yağış yağdığı üçün ailəm evdə qaldı və filmə baxdı.", level: "A2" },
  { en: "I forgot to charge my phone before I left the house.", az: "Evdən çıxmazdan əvvəl telefonumu enerji ilə doldurmağı unutdum.", level: "A2" },
  { en: "While my mother was preparing dinner, I set the table.", az: "Anam şam yeməyi hazırlayarkən mən süfrəni açdım.", level: "A2" },
  { en: "Could you tell me where the nearest bus stop is?", az: "Ən yaxın avtobus dayanacağının harada olduğunu deyə bilərsən?", level: "A2" },
  { en: "We have to leave early if we want to avoid the traffic.", az: "Tıxacdan yayınmaq istəyiriksə, tez çıxmalıyıq.", level: "A2" },
  { en: "The book you lent me was more interesting than I expected.", az: "Mənə verdiyin kitab gözlədiyimdən daha maraqlı idi.", level: "B1" },
  { en: "Although it was raining, we decided to walk to the restaurant.", az: "Yağış yağmasına baxmayaraq, restorana piyada getməyə qərar verdik.", level: "B1" },
  { en: "The train had already left when we arrived at the station.", az: "Vağzala çatanda qatar artıq getmişdi.", level: "B1" },
  { en: "She has been learning English for two years, but she still feels nervous when she speaks.", az: "O, iki ildir ingilis dili öyrənir, amma danışanda hələ də həyəcanlanır.", level: "B1" },
  { en: "He didn't go to work because he wasn't feeling well.", az: "Özünü yaxşı hiss etmədiyi üçün işə getmədi.", level: "A2" },
  { en: "If I have enough time this weekend, I'll help you paint the kitchen.", az: "Bu həftəsonu kifayət qədər vaxtım olsa, mətbəxi rəngləməyə sənə kömək edəcəyəm.", level: "B1" },
  { en: "The manager said that the meeting would start ten minutes later.", az: "Menecer iclasın on dəqiqə gec başlayacağını dedi.", level: "B1" },
  { en: "They were waiting for the bus when it suddenly started to snow.", az: "Birdən qar yağmağa başlayanda onlar avtobus gözləyirdilər.", level: "B1" },
  { en: "I couldn't hear the announcement because the station was too noisy.", az: "Vağzal çox səs-küylü olduğuna görə elanı eşidə bilmədim.", level: "B1" },
  { en: "She asked me to send the documents as soon as I got home.", az: "Evə çatan kimi sənədləri göndərməyimi istədi.", level: "B1" },
  { en: "By the time we reached the airport, our flight had already been delayed.", az: "Hava limanına çatanda uçuşumuz artıq gecikdirilmişdi.", level: "B1" },
  { en: "Unless we leave now, we will miss the beginning of the movie.", az: "İndi çıxmasaq, filmin başlanğıcını qaçıracağıq.", level: "B1" },
  { en: "I have never visited a place that was as quiet as this small village.", az: "Bu kiçik kənd qədər sakit bir yerə heç vaxt getməmişəm.", level: "B1" },
  { en: "If I had more free time, I would learn to play the guitar.", az: "Daha çox boş vaxtım olsaydı, gitara çalmağı öyrənərdim.", level: "B1" }
];
